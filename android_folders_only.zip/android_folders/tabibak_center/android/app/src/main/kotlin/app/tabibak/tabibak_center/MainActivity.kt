package app.tabibak.tabibak_center

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
