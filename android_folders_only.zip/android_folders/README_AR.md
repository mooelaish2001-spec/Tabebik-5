# طبيبك — مشاريع أندرويد الجاهزة (المستخدم · الطبيب · المركز)

## ما في الحزمة
```
tabibak_projects/
├─ tabibak_user/      تطبيق المريض   ┐  كل مشروع كامل وجاهز:
├─ tabibak_doctor/    تطبيق الطبيب   │  pubspec.yaml · analysis_options.yaml · lib/ (main.dart + tabibak_firebase.dart)
├─ tabibak_center/    تطبيق المركز   ┘  android/ (ملفات أندرويد الكاملة) · assets/ (للمريض)
├─ firebase/          قواعد الأمان: firestore.rules · storage.rules · firebase.json
├─ tools/setup.dart   (اختياري) بديل: يولّد المشاريع بـ flutter create ثم يعدّل أندرويد
└─ README_AR.md       هذا الدليل
```

## 1) التشغيل السريع (بدون Firebase)
```
cd tabibak_user
flutter pub get
flutter run
```
يعمل بالوضع التجريبي: رمز التحقق يظهر على الشاشة وبيانات نموذجية. كرّر مع `tabibak_doctor` و`tabibak_center`.

## 2) ملفات أندرويد (داخل كل مشروع: `android/`)
| الملف | الغرض |
|---|---|
| `settings.gradle.kts` | إعلان إضافات Gradle: Flutter · Android · Kotlin · Google Services |
| `build.gradle.kts` | إعدادات المستودعات ومسار البناء |
| `gradle.properties` | ذاكرة Gradle · AndroidX |
| `gradle/wrapper/gradle-wrapper.properties` | إصدار Gradle (8.10.2) |
| `app/build.gradle.kts` | معرّف التطبيق · `minSdk 23` · تفعيل Google Services **فقط عند وجود** `google-services.json` |
| `app/src/main/AndroidManifest.xml` | صلاحية الإنترنت · اسم التطبيق على الهاتف |
| `app/src/debug` و`profile` | صلاحية الإنترنت للتطوير |
| `app/src/main/kotlin/.../MainActivity.kt` | نشاط Flutter الرئيسي |
| `app/src/main/res/` | الأيقونات (5 أحجام) · شاشة البدء · الثيمات |
| `app/PUT_google-services.json_HERE.txt` | تذكير بمكان ملف Firebase |

معرّفات التطبيقات (Package name) التي تسجّلها في Firebase:

| التطبيق | المعرّف | الاسم على الهاتف |
|---|---|---|
| المريض | `app.tabibak.tabibak_user` | طبيبك |
| الطبيب | `app.tabibak.tabibak_doctor` | طبيبك للأطباء |
| المركز | `app.tabibak.tabibak_center` | طبيبك للمراكز |

الملفات `local.properties` و`gradlew` تُنشئهما أداة Flutter تلقائياً عند أول `flutter pub get` أو `flutter run`.

## 3) إن اشتكى Gradle من الإصدارات
الإصدارات المثبّتة: Gradle 8.10.2 · Android Gradle Plugin 8.7.3 · Kotlin 2.1.0 · Google Services 4.4.2 (تناسب معظم إصدارات Flutter الحديثة). إن ظهرت رسالة بأن إصدار Flutter يتطلب أحدث:
1. أنشئ مشروعاً مؤقتاً: `flutter create tmp_check`
2. من `tmp_check/android/settings.gradle.kts` انسخ أرقام `com.android.application` و`org.jetbrains.kotlin.android` إلى `settings.gradle.kts` عندك، ومن `tmp_check/android/gradle/wrapper/gradle-wrapper.properties` انسخ سطر `distributionUrl`.
3. احذف `tmp_check`.

## 4) استخدام ملفات أندرويد في مشروع Flutter موجود عندك
1. انسخ إلى مشروعك: `pubspec.yaml` و`analysis_options.yaml` و`lib/` (و`assets/` للمريض).
2. احذف مجلد `android/` القديم وانسخ بدلاً منه مجلد `android/` من هنا.
3. إن كان معرّف تطبيقك القديم مختلفاً فغيّره في `app/build.gradle.kts` (`namespace` و`applicationId`) وفي مسار `MainActivity.kt` وسطر `package` فيه، وسجّل هذا المعرّف في Firebase.

## 5) ربط Firebase
1. أنشئ **مشروعاً واحداً** في [console.firebase.google.com](https://console.firebase.google.com) وأضف **ثلاثة تطبيقات Android** بالمعرّفات أعلاه (المشروع الواحد يجعل البيانات مشتركة).
2. نزّل `google-services.json` لكل تطبيق وضعه في `tabibak_xxx/android/app/`.
3. **Authentication ← Sign-in method ← Phone**: فعّله.
   - أضف بصمتي **SHA-1 وSHA-256** لكل تطبيق (Project settings ← Your apps). للحصول عليهما:
     ```
     cd tabibak_user/android
     gradlew signingReport        (ماك/لينكس: ./gradlew signingReport)
     ```
     (إن لم يوجد `gradlew` شغّل `flutter pub get` أولاً.) خذ القيم من متغيّر `debug`. **عند بناء نسخة release أضف بصمات مفتاح الإصدار أيضاً** (وبصمة Google Play إن استخدمت Play App Signing) وإلا لن يصل رمز SMS في النسخة النهائية.
   - **Authentication ← Settings ← SMS region policy**: اسمح بالسودان (+249).
   - للتجربة بلا رسائل حقيقية: Phone ← *Phone numbers for testing* ← أضف رقماً ورمزاً (مثل `+249912345678` ← `123456`).
4. **Firestore Database**: أنشئها (Production mode). **Storage**: فعّله (يتطلب خطة Blaze).
5. انشر القواعد من مجلد `firebase/`:
   ```
   npm i -g firebase-tools
   firebase login
   firebase use --add          (اختر مشروعك)
   firebase deploy --only firestore:rules,storage
   ```
6. أعد تشغيل التطبيق (`flutter run` من جديد): إن ظهر في شاشة التحقق نص «وضع تجريبي» فـ Firebase لم يتهيأ (ملف json ناقص أو في غير `android/app/` أو معرّف غير مطابق).

## 6) الاعتماد اليدوي من لوحة Firebase (أنت)
| ماذا | أين | القيمة |
|---|---|---|
| اعتماد مركز | Firestore ← `centers/{id}` | `status` = `1` (معلّق 0 · معتمد 1 · مرفوض 2 مع `reason`) |
| توثيق طبيب | Firestore ← `doctors/{رقم المجلس}` | `verified` = `true` |
| مراجعة ترخيص المركز | Storage ← `licenses/{centerId}.jpg` | للاطلاع فقط |

لا يظهر الطبيب للمرضى قبل توثيقه، ولا يعمل المركز قبل اعتماده.

## 7) سيناريو تجربة كاملة (بهذا الترتيب)
1. **المركز:** سجّل مركزاً برقم (أ) ← من اللوحة اجعل `status = 1` (تتحول الشاشة تلقائياً) ← «بيانات المركز»: المدينة والحي و**الحساب البنكي**.
2. **الطبيب:** سجّل برقم (ب) ورقم مجلس (مثل 12345) وأكمل الملف ← من اللوحة `verified = true` ← «أماكن عملي»: اختر مركزك وأرسل الطلب.
3. **المركز:** «الأخصائيون» ← طلبات الانضمام ← قبول.
4. **المريض:** سجّل برقم (ج) ← «حجز طبيب»: ستجد الطبيب وبطاقة المركز **خضراء** ← احجز واكتب الشكوى واختر «تحويل إلى حساب المركز».
5. **المركز:** «الحجوزات» ← افتح الحجز ← قبول ← يصل المريض رقم الحساب.
6. **المريض:** يفتح الحجز ← «إرفاق إشعار التحويل من المعرض» ← يختار لقطة الشاشة.
7. **المركز:** يفتح الصورة ← «تأكيد استلام المبلغ».
8. **الطبيب:** حجز المريض يظهر في «عيانين الليلة» **يوم الموعد فقط**؛ المريض يحجز من الغد، فلتجربته غيّر تاريخ هاتف الطبيب إلى غد.

## 8) البناء للتوزيع
```
flutter build apk --release                 (ملف APK للتثبيت المباشر)
flutter build appbundle --release           (لمتجر Google Play)
```
النسخة الناتجة موقَّعة بمفتاح debug (صالحة للتجربة فقط). للنشر أنشئ مفتاح توقيع واتبع [docs.flutter.dev/deployment/android](https://docs.flutter.dev/deployment/android)، ولا تنسَ إضافة بصماته في Firebase (الخطوة 5).

## 9) الخطوط والصور (اختياري)
- **الخط Cairo** يُحمَّل من الإنترنت عند أول تشغيل. لتضمينه: نزّل Cairo من fonts.google.com، وضع ملفات `static/Cairo-{ExtraLight,Light,Regular,Medium,SemiBold,Bold,ExtraBold,Black}.ttf` في `assets/google_fonts/`، وأضف `- assets/google_fonts/` تحت `assets:` في `pubspec.yaml`.
- **صور المريض:** ضع `doctor1.jpg…doctor6.jpg` و`hospital1.jpg…hospital3.jpg` في `tabibak_user/assets/images/`. بدونها يظهر حرف ملوّن ولا يتعطل التطبيق.

## 10) مشاكل شائعة
| الأعراض | الحل |
|---|---|
| `flutter.sdk not set in local.properties` | شغّل `flutter pub get` داخل المشروع (ينشئ الملف). |
| `No matching client found for package name` | معرّف التطبيق في Firebase غير مطابق لـ `applicationId` في `app/build.gradle.kts`. |
| `app-not-authorized` / `missing-client-identifier` / `invalid-app-credential` | أضف SHA-1 وSHA-256 في Firebase، وفعّل «Play Integrity API» في Google Cloud للمشروع، أو استخدم أرقام الاختبار. |
| لا يصل SMS | راجع SMS region policy (+249)، وخطة Blaze، وجرّب رقم اختبار أولاً. |
| `permission-denied` في السجل | لم تُنشر القواعد، أو المركز غير معتمد، أو الطبيب غير موثّق. |
| `Gradle` يفشل بتحميل `google-services` | تحقق من الإنترنت أو الوكيل (proxy). |
| أخطاء إصدارات Gradle/Kotlin | الخطوة 3. |
| `flutter doctor` يشتكي من تراخيص | `flutter doctor --android-licenses` |

## 11) حدود معروفة
إشعارات الدفع والتطبيق مغلق (FCM) · أسرّة وخدمات المنزل والمعامل تبقى قوائم ثابتة عند المريض · حجز موعد مزدوج غير ممنوع · التقييمات محلية.
