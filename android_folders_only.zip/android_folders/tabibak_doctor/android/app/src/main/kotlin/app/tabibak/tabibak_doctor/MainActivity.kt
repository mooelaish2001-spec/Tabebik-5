package app.tabibak.tabibak_doctor

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
