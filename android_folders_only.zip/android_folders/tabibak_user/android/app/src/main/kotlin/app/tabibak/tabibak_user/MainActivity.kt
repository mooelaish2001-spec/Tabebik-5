package app.tabibak.tabibak_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
